package com.raftsurvival;

import net.fabricmc.fabric.api.entity.event.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.entity.vehicle.VehicleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.loot.LootTable;
import net.minecraft.potion.Potions;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Difficulty;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * All gameplay logic: raft start, drifting loot, floating crates, thirst and sharks.
 * Everything runs on the server thread.
 */
public final class RaftManager {
	// ---- tuning ----
	private static final int SEA_Y = 62;                 // top water block of the ocean dimension
	private static final double CURRENT_X = 0.07D;       // water current (blocks/tick), flows towards +X
	private static final double CURRENT_Z = 0.0D;
	private static final int MAX_THIRST = 20;
	private static final int THIRST_TICKS = 1000;        // ~50 s per thirst point
	private static final int THIRST_DAMAGE_TICKS = 80;
	private static final int WATER_BOTTLE_RESTORE = 7;
	private static final int ITEM_MIN_TICKS = 40;        // item every 2..10 s
	private static final int ITEM_MAX_TICKS = 200;
	private static final int CRATE_MIN_TICKS = 1800;     // crate every 1.5..3.5 min
	private static final int CRATE_MAX_TICKS = 4200;
	private static final int SHARK_MIN_TICKS = 600;
	private static final int SHARK_MAX_TICKS = 1500;
	private static final int MAX_SHARKS_NEAR = 2;
	private static final int MAX_CRATES = 4;

	private static final String TAG_STARTED = "raft_started";
	private static final String TAG_DRIFT = "raft_drift";
	private static final String TAG_THIRST_PREFIX = "raft_thirst_";

	private static final RegistryKey<LootTable> CRATE_LOOT = RegistryKey.of(
			RegistryKeys.LOOT_TABLE, Identifier.of(RaftMod.MOD_ID, "chests/floating_crate"));

	private static final Random RNG = new Random();
	private static final Map<UUID, PlayerState> STATES = new HashMap<>();
	private static final Set<UUID> PENDING_RETURN = new HashSet<>();
	private static final Set<Entity> TRACKED = Collections.newSetFromMap(new IdentityHashMap<>());

	private static final class PlayerState {
		int thirst;
		int thirstTimer;
		int damageTimer;
		int itemTimer = 100;
		int crateTimer = 400;
		int sharkTimer = 1200;

		PlayerState(int thirst) {
			this.thirst = thirst;
		}
	}

	/** Weighted drift loot: item id, weight, min count, max count. */
	private record Drop(String id, int weight, int min, int max) {}

	private static final List<Drop> DROPS = List.of(
			new Drop("oak_log", 12, 1, 3), new Drop("spruce_log", 4, 1, 3), new Drop("birch_log", 4, 1, 3),
			new Drop("jungle_log", 2, 1, 2), new Drop("acacia_log", 2, 1, 2), new Drop("dark_oak_log", 2, 1, 2),
			new Drop("oak_planks", 10, 2, 6), new Drop("stick", 8, 2, 6), new Drop("string", 5, 1, 3),
			new Drop("kelp", 6, 1, 3), new Drop("dried_kelp", 3, 1, 3), new Drop("sand", 6, 2, 5),
			new Drop("gravel", 4, 2, 4), new Drop("clay_ball", 5, 2, 5), new Drop("flint", 4, 1, 3),
			new Drop("coal", 6, 1, 3), new Drop("charcoal", 3, 1, 2), new Drop("raw_iron", 3, 1, 2),
			new Drop("iron_nugget", 5, 2, 6), new Drop("gold_nugget", 3, 2, 5), new Drop("raw_copper", 3, 1, 2),
			new Drop("bone", 4, 1, 2), new Drop("feather", 4, 1, 3), new Drop("leather", 3, 1, 2),
			new Drop("rotten_flesh", 3, 1, 2), new Drop("apple", 3, 1, 1), new Drop("carrot", 2, 1, 2),
			new Drop("potato", 2, 1, 2), new Drop("beetroot_seeds", 3, 1, 3), new Drop("wheat_seeds", 5, 2, 4),
			new Drop("melon_seeds", 2, 1, 2), new Drop("pumpkin_seeds", 2, 1, 2), new Drop("sweet_berries", 3, 1, 3),
			new Drop("oak_sapling", 4, 1, 2), new Drop("birch_sapling", 3, 1, 2), new Drop("spruce_sapling", 2, 1, 2),
			new Drop("jungle_sapling", 2, 1, 1), new Drop("acacia_sapling", 2, 1, 1), new Drop("dark_oak_sapling", 2, 1, 1),
			new Drop("bamboo", 3, 1, 3), new Drop("sugar_cane", 3, 1, 3), new Drop("cocoa_beans", 1, 1, 2),
			new Drop("glass_bottle", 3, 1, 1), new Drop("water_bottle", 5, 1, 1), new Drop("cobblestone", 6, 2, 5),
			new Drop("dirt", 4, 1, 3), new Drop("paper", 2, 1, 2), new Drop("white_wool", 2, 1, 2),
			new Drop("cod", 4, 1, 2), new Drop("salmon", 3, 1, 2), new Drop("bowl", 2, 1, 1), new Drop("bucket", 1, 1, 1)
	);
	private static final int DROPS_TOTAL_WEIGHT = DROPS.stream().mapToInt(Drop::weight).sum();

	private RaftManager() {}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(RaftManager::tick);

		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			if (!alive) {
				PENDING_RETURN.add(newPlayer.getUuid());
				STATES.remove(newPlayer.getUuid());
			}
		});

		// re-track drifting things after chunk (re)load / server restart
		ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
			if (entity.getCommandTags().contains(TAG_DRIFT)) {
				TRACKED.add(entity);
			}
		});

		UseItemCallback.EVENT.register(RaftManager::onUseItem);

		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			STATES.clear();
			TRACKED.clear();
			PENDING_RETURN.clear();
		});
	}

	// =====================================================================
	// main tick
	// =====================================================================

	private static void tick(MinecraftServer server) {
		ServerWorld raft = server.getWorld(RaftMod.RAFT_WORLD);
		if (raft == null) {
			return;
		}
		long time = server.getTicks();

		for (ServerWorld world : server.getWorlds()) {
			for (ServerPlayerEntity player : new ArrayList<>(world.getPlayers())) {
				handlePlayer(raft, world, player, time);
			}
		}
		updateDrift(raft, time);
	}

	private static void handlePlayer(ServerWorld raft, ServerWorld world, ServerPlayerEntity player, long time) {
		UUID id = player.getUuid();
		boolean newPlayer = !player.getCommandTags().contains(TAG_STARTED);
		boolean returning = PENDING_RETURN.contains(id);

		if (newPlayer || returning) {
			if (!player.isAlive()) {
				return;
			}
			PENDING_RETURN.remove(id);
			player.addCommandTag(TAG_STARTED);
			ensureRaft(raft);
			PlayerState fresh = new PlayerState(MAX_THIRST);
			STATES.put(id, fresh);
			writeThirst(player, MAX_THIRST);
			giveStarterKit(player, newPlayer);
			if (world != raft) {
				player.teleport(raft, 0.5D, SEA_Y + 1.0D, 0.5D, Set.of(), 0.0F, 0.0F, true);
			}
			return;
		}

		if (world != raft) {
			return;
		}

		PlayerState st = STATES.computeIfAbsent(id, k -> new PlayerState(readThirst(player)));
		handleFishingHook(player);

		if (player.isCreative() || player.isSpectator()) {
			return;
		}

		// ----- thirst -----
		if (++st.thirstTimer >= THIRST_TICKS) {
			st.thirstTimer = 0;
			if (st.thirst > 0) {
				setThirst(player, st, st.thirst - 1);
			}
		}
		if (st.thirst <= 0) {
			if (++st.damageTimer >= THIRST_DAMAGE_TICKS) {
				st.damageTimer = 0;
				if (player.getHealth() > 2.0F || raft.getDifficulty() == Difficulty.HARD) {
					player.damage(raft, raft.getDamageSources().starve(), 1.0F);
				}
			}
		} else {
			st.damageTimer = 0;
		}
		if (time % 20 == 0) {
			showThirst(player, st);
		}

		// ----- spawners -----
		if (--st.itemTimer <= 0) {
			st.itemTimer = ITEM_MIN_TICKS + RNG.nextInt(ITEM_MAX_TICKS - ITEM_MIN_TICKS);
			spawnDriftItem(raft, player);
		}
		if (--st.crateTimer <= 0) {
			st.crateTimer = CRATE_MIN_TICKS + RNG.nextInt(CRATE_MAX_TICKS - CRATE_MIN_TICKS);
			spawnCrate(raft, player);
		}
		if (--st.sharkTimer <= 0) {
			st.sharkTimer = SHARK_MIN_TICKS + RNG.nextInt(SHARK_MAX_TICKS - SHARK_MIN_TICKS);
			trySpawnShark(raft, player);
		}
	}

	// =====================================================================
	// raft + starter kit
	// =====================================================================

	private static void ensureRaft(ServerWorld raft) {
		for (int dx = -1; dx <= 1; dx++) {
			for (int dz = -1; dz <= 1; dz++) {
				BlockPos pos = new BlockPos(dx, SEA_Y, dz);
				BlockState state = raft.getBlockState(pos);
				if (state.isOf(Blocks.WATER) || state.isAir()) {
					raft.setBlockState(pos, Blocks.OAK_PLANKS.getDefaultState());
				}
			}
		}
	}

	private static void giveStarterKit(ServerPlayerEntity player, boolean full) {
		if (player.getInventory().count(Items.FISHING_ROD) == 0) {
			player.giveItemStack(new ItemStack(Items.FISHING_ROD));
		}
		if (full) {
			player.giveItemStack(new ItemStack(Items.COOKED_COD, 4));
			ItemStack bottles = waterBottle();
			bottles.setCount(2);
			player.giveItemStack(bottles);
			player.giveItemStack(new ItemStack(Items.OAK_PLANKS, 8));
		}
	}

	private static ItemStack waterBottle() {
		ItemStack stack = new ItemStack(Items.POTION);
		stack.set(DataComponentTypes.POTION_CONTENTS, new PotionContentsComponent(Potions.WATER));
		return stack;
	}

	private static boolean isWaterBottle(ItemStack stack) {
		if (!stack.isOf(Items.POTION)) {
			return false;
		}
		PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
		return contents != null && contents.potion().isPresent() && contents.potion().get().matches(Potions.WATER);
	}

	// =====================================================================
	// thirst
	// =====================================================================

	private static int readThirst(ServerPlayerEntity player) {
		for (String tag : player.getCommandTags()) {
			if (tag.startsWith(TAG_THIRST_PREFIX)) {
				try {
					return Math.max(0, Math.min(MAX_THIRST, Integer.parseInt(tag.substring(TAG_THIRST_PREFIX.length()))));
				} catch (NumberFormatException ignored) {
				}
			}
		}
		return MAX_THIRST;
	}

	private static void writeThirst(ServerPlayerEntity player, int value) {
		for (String tag : new ArrayList<>(player.getCommandTags())) {
			if (tag.startsWith(TAG_THIRST_PREFIX)) {
				player.removeCommandTag(tag);
			}
		}
		player.addCommandTag(TAG_THIRST_PREFIX + value);
	}

	private static void setThirst(ServerPlayerEntity player, PlayerState st, int value) {
		st.thirst = Math.max(0, Math.min(MAX_THIRST, value));
		writeThirst(player, st.thirst);
	}

	private static void showThirst(ServerPlayerEntity player, PlayerState st) {
		Formatting color = st.thirst > 10 ? Formatting.AQUA : (st.thirst > 5 ? Formatting.YELLOW : Formatting.RED);
		String bar = "|".repeat(st.thirst) + ".".repeat(MAX_THIRST - st.thirst);
		Text text = Text.literal("Thirst [" + bar + "]  " + st.thirst + "/" + MAX_THIRST).formatted(color);
		player.sendMessage(text, true);
	}

	private static ActionResult onUseItem(PlayerEntity player, World world, Hand hand) {
		if (!(player instanceof ServerPlayerEntity sp) || !(world instanceof ServerWorld sw)) {
			return ActionResult.PASS;
		}
		if (sw.getRegistryKey() != RaftMod.RAFT_WORLD) {
			return ActionResult.PASS;
		}
		ItemStack stack = sp.getStackInHand(hand);
		if (!isWaterBottle(stack)) {
			return ActionResult.PASS;
		}
		PlayerState st = STATES.computeIfAbsent(sp.getUuid(), k -> new PlayerState(readThirst(sp)));
		if (st.thirst >= MAX_THIRST) {
			return ActionResult.PASS;
		}
		setThirst(sp, st, st.thirst + WATER_BOTTLE_RESTORE);
		if (!sp.isCreative()) {
			stack.decrement(1);
			sp.giveItemStack(new ItemStack(Items.GLASS_BOTTLE));
		}
		sw.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.ENTITY_GENERIC_DRINK, SoundCategory.PLAYERS, 0.8F, 1.0F);
		showThirst(sp, st);
		return ActionResult.SUCCESS;
	}

	// =====================================================================
	// fishing: items are only collectable once they are hooked
	// =====================================================================

	private static void handleFishingHook(ServerPlayerEntity player) {
		FishingBobberEntity hook = player.fishHook;
		if (hook == null) {
			return;
		}
		Entity hooked = hook.getHookedEntity();
		if (hooked == null || !hooked.getCommandTags().contains(TAG_DRIFT)) {
			return;
		}
		if (hooked instanceof ItemEntity item) {
			item.setPickupDelay(0);
		}
		hooked.removeCommandTag(TAG_DRIFT);
		TRACKED.remove(hooked);
	}

	// =====================================================================
	// drifting things
	// =====================================================================

	private static void updateDrift(ServerWorld raft, long time) {
		boolean cull = time % 100 == 0;
		Iterator<Entity> it = TRACKED.iterator();
		while (it.hasNext()) {
			Entity e = it.next();
			if (e.isRemoved()) {
				it.remove();
				continue;
			}
			if (cull) {
				boolean near = false;
				for (ServerPlayerEntity p : raft.getPlayers()) {
					if (p.squaredDistanceTo(e) < 100.0D * 100.0D) {
						near = true;
						break;
					}
				}
				if (!near) {
					e.discard();
					it.remove();
					continue;
				}
			}
			if (e.isTouchingWater()) {
				Vec3d v = e.getVelocity();
				e.setVelocity(CURRENT_X, v.y, CURRENT_Z);
			}
		}
	}

	private static ItemStack rollDriftStack() {
		int roll = RNG.nextInt(DROPS_TOTAL_WEIGHT);
		for (Drop drop : DROPS) {
			roll -= drop.weight();
			if (roll < 0) {
				int count = drop.min() + RNG.nextInt(drop.max() - drop.min() + 1);
				ItemStack stack;
				if (drop.id().equals("water_bottle")) {
					stack = waterBottle();
				} else {
					var item = Registries.ITEM.get(Identifier.of("minecraft", drop.id()));
					if (item == Items.AIR) {
						return ItemStack.EMPTY;
					}
					stack = new ItemStack(item);
				}
				stack.setCount(count);
				return stack;
			}
		}
		return ItemStack.EMPTY;
	}

	private static void spawnDriftItem(ServerWorld raft, ServerPlayerEntity player) {
		double x = player.getX() - 48.0D - RNG.nextInt(8);
		double z = player.getZ() + (RNG.nextDouble() * 2.0D - 1.0D) * 12.0D;
		BlockPos pos = BlockPos.ofFloored(x, SEA_Y, z);
		if (!raft.getBlockState(pos).isOf(Blocks.WATER)) {
			return;
		}
		ItemStack stack = rollDriftStack();
		if (stack.isEmpty()) {
			return;
		}
		ItemEntity item = new ItemEntity(raft, x, SEA_Y + 0.5D, z, stack);
		item.setPickupDelay(32767); // cannot be picked up until hooked with a fishing rod
		item.addCommandTag(TAG_DRIFT);
		item.setVelocity(CURRENT_X, 0.0D, CURRENT_Z);
		raft.spawnEntity(item);
	}

	private static void spawnCrate(ServerWorld raft, ServerPlayerEntity player) {
		int crates = 0;
		for (Entity e : TRACKED) {
			if (e instanceof VehicleInventory && !e.isRemoved()) {
				crates++;
			}
		}
		if (crates >= MAX_CRATES) {
			return;
		}
		double x = player.getX() - 48.0D - RNG.nextInt(8);
		double z = player.getZ() + (RNG.nextDouble() * 2.0D - 1.0D) * 8.0D;
		BlockPos pos = BlockPos.ofFloored(x, SEA_Y, z);
		if (!raft.getBlockState(pos).isOf(Blocks.WATER)) {
			return;
		}
		Entity boat = EntityType.OAK_CHEST_BOAT.create(raft, SpawnReason.EVENT);
		if (boat == null) {
			return;
		}
		if (boat instanceof VehicleInventory inventory) {
			inventory.setLootTable(CRATE_LOOT);
		}
		boat.setPosition(x, SEA_Y + 0.6D, z);
		boat.setYaw(RNG.nextFloat() * 360.0F);
		boat.addCommandTag(TAG_DRIFT);
		raft.spawnEntity(boat);
	}

	private static void trySpawnShark(ServerWorld raft, ServerPlayerEntity player) {
		if (raft.getDifficulty() == Difficulty.PEACEFUL) {
			return;
		}
		int near = raft.getEntitiesByClass(SharkEntity.class, player.getBoundingBox().expand(80.0D), e -> true).size();
		if (near >= MAX_SHARKS_NEAR) {
			return;
		}
		double angle = RNG.nextDouble() * Math.PI * 2.0D;
		double dist = 22.0D + RNG.nextDouble() * 12.0D;
		double x = player.getX() + Math.cos(angle) * dist;
		double z = player.getZ() + Math.sin(angle) * dist;
		int y = SEA_Y - 3 - RNG.nextInt(6);
		BlockPos pos = BlockPos.ofFloored(x, y, z);
		if (!raft.getBlockState(pos).isOf(Blocks.WATER) || !raft.getBlockState(pos.up()).isOf(Blocks.WATER)) {
			return;
		}
		SharkEntity shark = ModEntities.SHARK.create(raft, SpawnReason.EVENT);
		if (shark == null) {
			return;
		}
		shark.setPosition(x, y, z);
		shark.setYaw(RNG.nextFloat() * 360.0F);
		raft.spawnEntity(shark);
	}
}
