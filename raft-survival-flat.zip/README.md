# Raft Survival (Fabric 1.21.11)

Raft-style ocean survival mod.

- New players (and respawning players) are sent to an endless ocean (`raft_survival:ocean`) and stand on a 3x3 oak raft.
- Every 2-10 s a random item drifts toward the raft. Items can't be picked up by hand: hook them with a fishing rod (you start with one).
- Every 1.5-3.5 min a floating crate (chest boat with a loot table) drifts by. Hook it, then open it.
- Thirst (action bar): -1 every ~50 s. Drink Water Bottles (right-click) for +7. At 0 you take damage.
- Sharks: hostile, circle in the water and bite players at the raft edge.
- Only sensible materials appear (no command blocks, spawners, etc.).

## Build (GitHub)
Push the repo -> Actions tab -> "Build mod" -> download the `raft-survival-jar` artifact.
Use the jar WITHOUT `-sources`. Requires Fabric Loader 0.18.1+ and Fabric API 0.140.0+1.21.11 (or newer for 1.21.11).
