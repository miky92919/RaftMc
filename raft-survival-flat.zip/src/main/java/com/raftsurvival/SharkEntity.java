package com.raftsurvival;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.control.AquaticMoveControl;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.SwimAroundGoal;
import net.minecraft.entity.ai.pathing.EntityNavigation;
import net.minecraft.entity.ai.pathing.SwimNavigation;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.WaterCreatureEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;

/**
 * A hostile shark: lurks and circles in the water, hunts survival players,
 * and bites anyone standing at the edge of the raft.
 */
public class SharkEntity extends WaterCreatureEntity {

	public SharkEntity(EntityType<? extends SharkEntity> type, World world) {
		super(type, world);
		this.moveControl = new AquaticMoveControl(this, 85, 10, 0.02F, 0.1F, true);
	}

	@Override
	protected void initGoals() {
		this.goalSelector.add(1, new MeleeAttackGoal(this, 1.6D, true));
		this.goalSelector.add(2, new SwimAroundGoal(this, 1.0D, 40));
		this.goalSelector.add(3, new LookAroundGoal(this));
		this.targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
	}

	@Override
	protected EntityNavigation createNavigation(World world) {
		return new SwimNavigation(this, world);
	}

	public static DefaultAttributeContainer.Builder createSharkAttributes() {
		return MobEntity.createMobAttributes()
				.add(EntityAttributes.MAX_HEALTH, 30.0D)
				.add(EntityAttributes.MOVEMENT_SPEED, 2.0D)
				.add(EntityAttributes.ATTACK_DAMAGE, 6.0D)
				.add(EntityAttributes.FOLLOW_RANGE, 28.0D)
				.add(EntityAttributes.WATER_MOVEMENT_EFFICIENCY, 1.0D);
	}

	@Override
	public void tickMovement() {
		super.tickMovement();
		// keep idle sharks near the surface so the player can see them
		if (this.isTouchingWater() && this.getTarget() == null && this.getY() < 56.0D) {
			this.setVelocity(this.getVelocity().add(0.0D, 0.01D, 0.0D));
		}
	}
}
