package com.raftsurvival;

import net.fabricmc.api.ModInitializer;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

public class RaftMod implements ModInitializer {
	public static final String MOD_ID = "raft_survival";

	/** The endless ocean dimension (defined in data/raft_survival/dimension/ocean.json). */
	public static final RegistryKey<World> RAFT_WORLD =
			RegistryKey.of(RegistryKeys.WORLD, Identifier.of(MOD_ID, "ocean"));

	@Override
	public void onInitialize() {
		ModEntities.init();
		RaftManager.init();
	}
}
