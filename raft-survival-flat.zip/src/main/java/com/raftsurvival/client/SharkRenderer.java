package com.raftsurvival.client;

import com.raftsurvival.RaftMod;
import com.raftsurvival.SharkEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class SharkRenderer extends MobEntityRenderer<SharkEntity, SharkRenderState, SharkModel> {
	private static final Identifier TEXTURE = Identifier.of(RaftMod.MOD_ID, "textures/entity/shark.png");

	public SharkRenderer(EntityRendererFactory.Context context) {
		super(context, new SharkModel(context.getPart(SharkModel.LAYER)), 0.9F);
	}

	@Override
	public Identifier getTexture(SharkRenderState state) {
		return TEXTURE;
	}

	@Override
	public SharkRenderState createRenderState() {
		return new SharkRenderState();
	}
}
