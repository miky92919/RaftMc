package com.raftsurvival.client;

import net.minecraft.client.render.entity.state.LivingEntityRenderState;

public class SharkRenderState extends LivingEntityRenderState {
}
