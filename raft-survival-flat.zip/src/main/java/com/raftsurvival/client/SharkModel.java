package com.raftsurvival.client;

import com.raftsurvival.RaftMod;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

public class SharkModel extends EntityModel<SharkRenderState> {
	public static final EntityModelLayer LAYER =
			new EntityModelLayer(Identifier.of(RaftMod.MOD_ID, "shark"), "main");

	private final ModelPart body;
	private final ModelPart tail;
	private final ModelPart leftFin;
	private final ModelPart rightFin;

	public SharkModel(ModelPart root) {
		super(root);
		this.body = root.getChild("body");
		this.tail = this.body.getChild("tail");
		this.leftFin = this.body.getChild("left_fin");
		this.rightFin = this.body.getChild("right_fin");
	}

	public static TexturedModelData createModelData() {
		ModelData data = new ModelData();
		ModelPartData root = data.getRoot();

		ModelPartData body = root.addChild("body",
				ModelPartBuilder.create().uv(0, 0).cuboid(-6.0F, -6.0F, -14.0F, 12.0F, 12.0F, 28.0F),
				ModelTransform.of(0.0F, 14.0F, 0.0F, 0.0F, 0.0F, 0.0F));

		body.addChild("snout",
				ModelPartBuilder.create().uv(80, 0).cuboid(-5.0F, -4.0F, -22.0F, 10.0F, 9.0F, 8.0F),
				ModelTransform.NONE);
		body.addChild("jaw",
				ModelPartBuilder.create().uv(84, 52).cuboid(-4.0F, 5.0F, -21.0F, 8.0F, 2.0F, 7.0F),
				ModelTransform.NONE);
		body.addChild("dorsal_fin",
				ModelPartBuilder.create().uv(80, 20).cuboid(-0.5F, -14.0F, -3.0F, 1.0F, 8.0F, 8.0F),
				ModelTransform.NONE);
		body.addChild("left_fin",
				ModelPartBuilder.create().uv(84, 42).cuboid(0.0F, 0.0F, 0.0F, 8.0F, 1.0F, 6.0F),
				ModelTransform.of(5.0F, 5.0F, -8.0F, 0.0F, 0.0F, 0.5F));
		body.addChild("right_fin",
				ModelPartBuilder.create().uv(84, 42).cuboid(-8.0F, 0.0F, 0.0F, 8.0F, 1.0F, 6.0F),
				ModelTransform.of(-5.0F, 5.0F, -8.0F, 0.0F, 0.0F, -0.5F));

		ModelPartData tail = body.addChild("tail",
				ModelPartBuilder.create().uv(0, 42).cuboid(-4.0F, -4.0F, 0.0F, 8.0F, 8.0F, 12.0F),
				ModelTransform.of(0.0F, 0.0F, 14.0F, 0.0F, 0.0F, 0.0F));
		tail.addChild("tail_fin_upper",
				ModelPartBuilder.create().uv(44, 42).cuboid(-0.5F, -12.0F, 0.0F, 1.0F, 12.0F, 8.0F),
				ModelTransform.of(0.0F, 0.0F, 10.0F, 0.0F, 0.0F, 0.0F));
		tail.addChild("tail_fin_lower",
				ModelPartBuilder.create().uv(66, 42).cuboid(-0.5F, 0.0F, 0.0F, 1.0F, 7.0F, 6.0F),
				ModelTransform.of(0.0F, 0.0F, 10.0F, 0.0F, 0.0F, 0.0F));

		return TexturedModelData.of(data, 128, 64);
	}

	@Override
	public void setAngles(SharkRenderState state) {
		super.setAngles(state);
		float swing = MathHelper.sin(state.age * 0.35F) * 0.35F;
		this.tail.yaw = swing;
		this.body.yaw = -swing * 0.15F;
		float flap = MathHelper.sin(state.age * 0.2F) * 0.12F;
		this.leftFin.roll = 0.5F + flap;
		this.rightFin.roll = -0.5F - flap;
	}
}
