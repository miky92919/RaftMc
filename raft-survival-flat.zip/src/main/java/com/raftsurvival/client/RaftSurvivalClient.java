package com.raftsurvival.client;

import com.raftsurvival.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class RaftSurvivalClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		EntityModelLayerRegistry.registerModelLayer(SharkModel.LAYER, SharkModel::createModelData);
		EntityRendererRegistry.register(ModEntities.SHARK, SharkRenderer::new);
	}
}
