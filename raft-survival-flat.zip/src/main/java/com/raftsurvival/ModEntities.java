package com.raftsurvival;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

public final class ModEntities {
	private static final RegistryKey<EntityType<?>> SHARK_KEY =
			RegistryKey.of(RegistryKeys.ENTITY_TYPE, Identifier.of(RaftMod.MOD_ID, "shark"));

	public static final EntityType<SharkEntity> SHARK = Registry.register(
			Registries.ENTITY_TYPE,
			SHARK_KEY,
			EntityType.Builder.create(SharkEntity::new, SpawnGroup.WATER_CREATURE)
					.dimensions(1.6F, 1.0F)
					.build(SHARK_KEY)
	);

	private ModEntities() {}

	public static void init() {
		FabricDefaultAttributeRegistry.register(SHARK, SharkEntity.createSharkAttributes());
	}
}
